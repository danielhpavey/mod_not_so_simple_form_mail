mod_not_so_simple_form_mail
=======================

A super simple Joomla! module to create a basic webpage form in a Joomla! website
