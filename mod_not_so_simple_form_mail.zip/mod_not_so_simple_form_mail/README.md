mod_not_so_simple_form_mail
=======================

A super simple Joomla! module to create a basic webpage form in a Joomla! website

The latest update uses jQuery for frontend form validation

**Please Note**
I have included the [jQuery Validator Plugin](http://jqueryvalidation.org/) in this module, but you will need to link it up appropriately in your template.

I have not set this module to do it for you so that you can retain control of where the script appears on your site (rather then just putting it in the header as Joomla! does)

P.S. you'll also need to link up to jQuery!!
